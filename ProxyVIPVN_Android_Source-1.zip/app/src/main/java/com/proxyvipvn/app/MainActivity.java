package com.proxyvipvn.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(15, 17, 29);
    private final int cyan = Color.rgb(37, 223, 255);
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("PROXY VIP VN", 28, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = text("FREE FIRE SUPPORT", 13, cyan, true);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = params(-1, -2); sp.bottomMargin = dp(22);
        root.addView(sub, sp);

        addSwitch("Proxy Body", "Giao diện bật/tắt");
        addSwitch("Proxy Neck", "Giao diện bật/tắt");
        addSwitch("Proxy Drag", "Giao diện bật/tắt");
        addSwitch("Proxy Magic", "Giao diện bật/tắt");

        TextView keyTitle = text("KEY KÍCH HOẠT", 16, Color.WHITE, true);
        LinearLayout.LayoutParams kt = params(-1,-2); kt.topMargin=dp(16); kt.bottomMargin=dp(8);
        root.addView(keyTitle, kt);
        EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setHint("Nhập KEY FREE hoặc KEY VV");
        key.setHintTextColor(Color.GRAY);
        key.setTextColor(Color.WHITE);
        key.setPadding(dp(14), 0, dp(14), 0);
        key.setBackground(round(Color.rgb(29,32,49), cyan, 1, 12));
        root.addView(key, params(-1, dp(52)));

        Button validate = button("XÁC THỰC KEY");
        LinearLayout.LayoutParams vp=params(-1,dp(50)); vp.topMargin=dp(10);
        root.addView(validate,vp);
        validate.setOnClickListener(v -> {
            if (key.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập key.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Chưa kết nối máy chủ xác thực. Key chưa được xác minh.", Toast.LENGTH_LONG).show();
            }
        });

        Button open = button("▶  MỞ GAME");
        LinearLayout.LayoutParams op=params(-1,dp(54)); op.topMargin=dp(18);
        root.addView(open,op);
        open.setOnClickListener(v -> openGame());
        TextView note = text("Các công tắc là tùy chọn giao diện, không can thiệp cơ chế ngắm trong game.", 12, Color.LTGRAY, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np=params(-1,-2); np.topMargin=dp(16);
        root.addView(note,np);
    }

    private void addSwitch(String name, String desc) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(10), dp(12), dp(10));
        card.setBackground(round(Color.rgb(24,27,43), Color.rgb(48,54,78), 1, 14));
        LinearLayout.LayoutParams cp=params(-1,-2); cp.bottomMargin=dp(10);
        root.addView(card,cp);
        LinearLayout labels = new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL);
        TextView n=text(name,16,Color.WHITE,true);
        TextView d=text(desc,12,Color.LTGRAY,false);
        labels.addView(n); labels.addView(d);
        card.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this); sw.setText("");
        card.addView(sw,params(-2,-2));
    }

    private void openGame() {
        String[] packages={"com.dts.freefireth","com.dts.freefiremax"};
        PackageManager pm=getPackageManager();
        for(String p:packages) {
            Intent i=pm.getLaunchIntentForPackage(p);
            if(i!=null){ startActivity(i); return; }
        }
        Toast.makeText(this,"Không tìm thấy Free Fire hoặc Free Fire MAX đã cài.",Toast.LENGTH_LONG).show();
    }

    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setTypeface(null,Typeface.BOLD);
        b.setBackground(round(Color.rgb(119,76,235), Color.rgb(119,76,235), 1, 14));
        return b;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD); return t;
    }
    private GradientDrawable round(int color,int stroke,int width,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(width),stroke); return d;
    }
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
